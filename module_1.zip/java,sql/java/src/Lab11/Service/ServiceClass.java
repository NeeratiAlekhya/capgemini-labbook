package Lab11.Service;

public class ServiceClass {

}
