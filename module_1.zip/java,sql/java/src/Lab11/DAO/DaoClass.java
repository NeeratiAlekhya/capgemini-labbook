package Lab11.DAO;

import java.util.HashMap;

import Lab11.Employee;

public class DaoClass implements DaoInterface{
	static HashMap<Integer, Employee> h = new HashMap<Integer, Employee>();
	public void add(Employee e) {
		
		h.put(e.getEmpid(), e);
		System.out.println("successfully added");
		System.out.println(h.get(e.getEmpid()));
	}

	public Employee selectData(int nid) {
		System.out.println(" in dao class");
		return h.get(nid);
	}

	public void getAllData() {
		
		System.out.println(h);
	}
}
