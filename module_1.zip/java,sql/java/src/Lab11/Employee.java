package Lab11;

public class Employee {
	public int Empid;
	public String Empname;
	public double Empsalary;
	public String Designation;
	public String InsuranceScheme;
	public Employee(int empid, String empname, double empsalary, String Designation, String InsuranceScheme) {
		super();
		Empid = empid;
		Empname = empname;
		Empsalary = empsalary;
		Designation = Designation;
		InsuranceScheme = InsuranceScheme;
	}
	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getEmpname() {
		return Empname;
	}
	public void setEmpname(String empname) {
		Empname = empname;
	}
	public double getEmpsalary() {
		return Empsalary;
	}
	public void setEmpsalary(double empsalary) {
		Empsalary = empsalary;
	}
	public String getEmpdesignation() {
		return Designation;
	}
	public void setEmpdesignation(String empdesignation) {
		Designation = empdesignation;
	}
	public String getEmpinsuranceScheme() {
		return InsuranceScheme;
	}
	public void setEmpinsuranceScheme(String empinsuranceScheme) {
		InsuranceScheme = empinsuranceScheme;
	}
	@Override
	public String toString() {
		return "Employee [Empid=" + Empid + ", Empname=" + Empname + ", Empsalary=" + Empsalary + ", Empdesignation="
				+ Designation + ", EmpinsuranceScheme=" + InsuranceScheme + "]";
	}
}
