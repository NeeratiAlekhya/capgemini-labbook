package Lab10;
interface Fact{
	int factorial(int a);
}
public class FactMethod {
	public int Method(int a)
	{
		for(int i=a-1;i>0;i--)
		{
			a=a*i;
		}
		return a;
	}
}
