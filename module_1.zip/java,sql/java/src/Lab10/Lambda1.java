package Lab10;

public class Lambda1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MathOperation power=(int x,int y) ->Math.pow(x, y);
		System.out.println(power.Operation(2, 2));
		}
		}
interface MathOperation
{
	double Operation(int x,int y);
}

