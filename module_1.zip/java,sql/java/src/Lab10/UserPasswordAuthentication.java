package Lab10;

public class UserPasswordAuthentication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Authentication a=(String username,String password) ->{
			    if(username==password)
			        return true;
			    else
				    return false;
		};
		System.out.println(a.Operation("abc","abc"));
		}
		}
		interface Authentication
		{
			Boolean Operation(String username,String password);
	   }
