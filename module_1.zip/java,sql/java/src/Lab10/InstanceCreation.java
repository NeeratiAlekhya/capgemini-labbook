package Lab10;

public class InstanceCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Build b=new Build(19,"Alekhya");
		InstanceId i2=b::getId;
		System.out.println(i2.id());
		InstanceName i1=b::getName;
		System.out.println(i1.name());

	}
	}

