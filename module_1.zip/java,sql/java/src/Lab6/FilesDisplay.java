package Lab6;

import java.io.File;
import java.util.Scanner;

public class FilesDisplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("enter string ");
			String s=input.nextLine();
		 	File f1=new File(s);	
		 	System.out.println("File Name:"+f1.getName());
			System.out.println("Path:"+f1.getPath());
			System.out.println("Abs Path:"+f1.getAbsolutePath());
			System.out.println("This file is:"+(f1.exists()?"Exists":"Does not exists"));
			System.out.println("Is file:"+f1.isFile());
			System.out.println("Is Readable:"+f1.canRead());
			System.out.println("IS Writable:"+f1.canWrite());
		 System.out.println("File Size:"+f1.length()+"bytes");
		 if (s.endsWith(".jpg") ||s.endsWith(".gif") ||s.endsWith(".png"))
		    {
		    System.out.println("The given file is an image file.");}
		       else if (s.endsWith(".exe"))
		      {
		   System.out.println("The given file is an executable file.");
		     }
		      else if (s.endsWith(".java"))
		    {
		  System.out.println("The given file is an Java file.");
		  }
		   else if (s.endsWith(".txt"))
		      {   
		    System.out.println("The given file is a text file.");
		     }
		     else
		     {
		    System.out.println("The file type is unknown.");
		      }}}


