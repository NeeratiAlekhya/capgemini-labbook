package Lab6;

import java.util.Scanner;

public class ModifyingNumber {
	public static int modifyNumber(int number1)
	{
		String s=Integer.toString(number1);
		char ch[]=new char[s.length()];
		for(int i=0;i<s.length();i++)
		{
			ch[i]=s.charAt(i);
		}
		int n[]=new int[ch.length];
		for(int i=0;i<ch.length;i++)
		{
			n[i]=Character.getNumericValue(ch[i]);
		}
			int diff[]=new int[n.length];
		for(int i=0;i<n.length;i++)
		{
			if(i==n.length-1)
			{
				diff[i]=Math.abs(n[i]-n[0]);
			}
			else
		      diff[i]=Math.abs(n[i]-n[i+1]);
		}
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<n.length;i++)
		{
			sb.append(diff[i]);
		}
		String s1=sb.toString();
		int m=Integer.parseInt(s1);
		return m;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number ");
		num1=sc.nextInt();
		System.out.println(modifyNumber(num1));

	}
}
