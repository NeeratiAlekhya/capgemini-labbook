package Lab6;

import java.util.Scanner;

public class ConsonantReplacing {
	public static String alterString(String s1) 
	{
		char s[]=s1.toCharArray();
		for(int i=0;i<s1.length();i++)
		{
			if(s[i]!='a'&& s[i]!='e'&&s[i]!='i'&&s[i]!='o'&&s[i]!='u'&&s[i]!='A'&& s[i]!='E'&&s[i]!='I'&&s[i]!='O'&&s[i]!='U')
			{
				s[i]=(char) (s[i]+1);
			}
		}
		String str=new String(s);
		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string  ");
		s1=sc.next();
		System.out.println(alterString(s1));
	}
	}
