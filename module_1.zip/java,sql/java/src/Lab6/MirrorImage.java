package Lab6;
import java.io.*;
public class MirrorImage {
	public static String getImage(String str)
	{
		StringBuffer sb=new StringBuffer(str);
		sb=sb.reverse();
		String str1=sb.toString();
		return str+"|"+str1;
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader n1=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter a string ");
		String str=n1.readLine();
		System.out.println(getImage(str));
		n1.close();
	}
	}
