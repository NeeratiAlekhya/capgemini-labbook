package Lab6;

import java.util.Scanner;
import java.util.StringTokenizer;

public class LineOfIntegers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		int i,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array of integers  "); //give in same line with spaces
		str=sc.nextLine();
		StringTokenizer st=new StringTokenizer(str);
		while(st.hasMoreTokens()){
			String s=st.nextToken();
			i=Integer.parseInt(s);
			System.out.println(i);
			sum+=i;
		}
		System.out.println("sum="+sum);
		
	}
	}
