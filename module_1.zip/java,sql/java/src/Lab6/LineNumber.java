package Lab6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class LineNumber {

	public static void main(String[] args) throws FileNotFoundException, IOException{
		// TODO Auto-generated method stub
		FileReader f1=new FileReader("c:\\files\\sample.txt");
		BufferedReader b1=new BufferedReader(f1);
		String line=null;
		LineNumberReader ln=new LineNumberReader(f1);
		while((line=ln.readLine())!=null)
		{
			int i=ln.getLineNumber();
			System.out.println(i+" "+line);
	}
	f1.close();b1.close();}
	}
