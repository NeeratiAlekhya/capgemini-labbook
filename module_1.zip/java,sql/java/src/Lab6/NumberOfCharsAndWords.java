package Lab6;
import java.util.*;
import java.io.*;
public class NumberOfCharsAndWords {
public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
             int a=1,b=0;           
             char ch;
             Scanner sc=new Scanner(System.in);
		        String str=sc.nextLine();
             FileInputStream f=null;
             f=new FileInputStream("c:\\files\\sample.txt");
             int n=f.available();
             for(int i=0;i<n;i++)
             {
              ch=(char)f.read();
	             if(ch=='\n')
	             a++;
	             else if(ch==' ')
	             b++;
}
 System.out.println("\nNumber of lines : "+a);
 System.out.println("\nNumber of words : "+(a+b));
 System.out.println("\nNumber of characters : "+n);
} }

