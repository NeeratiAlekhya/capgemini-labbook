package Lab4;

import java.util.Scanner;

public class SumCubes {
	public  int SumOfCubes(int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
		sum+=(i*i*i);
		return sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		SumCubes s= new SumCubes();
		System.out.println(s.SumOfCubes(n));
	}
	}
