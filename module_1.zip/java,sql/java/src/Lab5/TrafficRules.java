package Lab5;

import java.util.Scanner;

public class TrafficRules {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String choice=null;
		Scanner sc=new Scanner(System.in);
System.out.println("enter your choice");
choice=sc.next();
if(choice.equals("red"))
{ System.out.println("stop");
}else if(choice.equals("yellow"))
{ System.out.println("ready");
}else if(choice.equals("green"))
{System.out.println("go");
}
}}
