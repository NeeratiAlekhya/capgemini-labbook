package Lab5;

public class EmployeeException1 extends Exception {
	public EmployeeException1(String msg)
	{
		System.out.println(msg);
	}
}
