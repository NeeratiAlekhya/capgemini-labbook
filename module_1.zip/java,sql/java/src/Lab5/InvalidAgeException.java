package Lab5;

public class InvalidAgeException extends Exception {
	public InvalidAgeException(String msg)
	{
		System.out.println(msg);
	}
}
