package Lab5;

import java.util.Scanner;

public class FibonacciSeq {
	public int fib(int n)
	  {
	  int a=0,b=1,c;
	  System.out.println(a);
	  System.out.println(b);
	  for(int i=0;i<n;i++)
	  {
		  c=a+b;
		  System.out.println(c);
		  a=b;
		  b=c;
	  }
	  return n;
	  }
	  public int FibRecursive(int n)
	  {
		 if(n==0) 
		 {
			 return 0;
		 }
		 if(n==1||n==2)
		 {
			  return 1;
		 }
		  return FibRecursive(n-2)+FibRecursive(n-1);
	  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		  Scanner sc=new Scanner(System.in);
		  System.out.println("Enter n value");
		  int n=sc.nextInt();
		  FibonacciSeq fb =new FibonacciSeq();
		  fb.fib(n);
		  for(int i=1;i<=n;i++)
		  {
		  System.out.println(fb.FibRecursive(i));
		  }
	}

}
