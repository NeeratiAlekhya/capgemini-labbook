package Lab5;

import java.util.Scanner;

public class AgeValidity {

	public static void main(String[] args) throws InvalidAgeException {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter age");
		int age=sc.nextInt();
		if(age<15)
			throw new InvalidAgeException("Invalid Age");
		else
			System.out.println("valid Age");
		
	}
	}
