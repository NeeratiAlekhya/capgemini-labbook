package Lab5;

import java.util.Scanner;

public class PrimeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Scanner sc =new Scanner(System.in);
			int n=sc.nextInt();
			for(int i=1;i<=n;i++)
			{int flag=1;
				for(int j=2;j<=i-1;j++)
			{
				if(i%j==0)
				{flag= 0;
				break;
				}
			}
			if(flag==1)
			{System.out.println(i);
		}
	}}
	}
