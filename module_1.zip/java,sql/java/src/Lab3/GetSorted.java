package Lab3;

import java.util.Scanner;
import java.util.*;
public class GetSorted {
	int[] getSorted(int[] array1)
	{
	String array= Arrays.toString(array1);
	String array2= array.substring(1,(array.length())-1);
	StringBuilder sb=new StringBuilder((array2));
	System.out.println(sb.reverse());
	for(int i=0;i<array1.length;i++)
	{
		for(int j=i+1;j<array1.length;j++)
		{
		if(array1[i]>array1[j])
		{
			int temp=array1[i];
			array1[i]=array1[j];
			array1[j]=temp;
		}
		}
	}
	return array1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array1=new int[5];
		Scanner sc=new Scanner(System.in);
		GetSorted r=new GetSorted();
		for(int i=0;i<array1.length;i++)
			array1[i]=sc.nextInt();
		int[] result=r.getSorted(array1);
		for(int i=0;i<result.length;i++)
			System.out.println(result[i]);
	} 
	}
