package Lab3;

import java.util.Scanner;

public class UpperLowerCase {
public String sortString(String name){
		char[] sort=new char[name.length()];
		for(int i=0;i<name.length();i++)
		{
			sort[i]=name.charAt(i);
		}
		for(int i=0;i<name.length();i++)
		{
			for(int j=i+1;j<name.length();j++)
			{
				if(sort[i]>sort[j])
				{
					char temp=sort[i];
					sort[i]=sort[j];
					sort[j]=temp;
				}
			}
		}
		if((name.length())%2==0)
		{for(int i=0;i<name.length()/2;i++)
			sort[i]=Character.toUpperCase(sort[i]);
		}
		else{
			for(int i=0;i<(name.length()/2)+1;i++)
			{
				sort[i]=Character.toUpperCase(sort[i]);
			}
		}
		return new String(sort); 
	}
		public static void main(String[] args) {
			String[] name=new String[3];
			UpperLowerCase d=new UpperLowerCase();
			Scanner sc= new Scanner(System.in);
			for(int i=0;i<name.length;i++)
			{
				name[i]=sc.nextLine();
			}
			for(int i=0;i<name.length;i++)
			{
				System.out.println(d.sortString(name[i]));
			}
		}
}
