package Lab3;

import java.util.Scanner;

public class CharArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[26];
		System.out.println("enter array characters   ");
		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++)
		{ if(s.charAt(i)>=65 && s.charAt(i)<=90)
		{a[s.charAt(i)-65]++;
		}
		else if(s.charAt(i)>=97 && s.charAt(i)<=122)
		{a[s.charAt(i)-97]++;
		}}
		for(int i=0;i<26;i++)
		{
		  if(a[i]>0){
			System.out.println((char)(i+97)+ "  "+a[i]);
		}}
	}
	}
