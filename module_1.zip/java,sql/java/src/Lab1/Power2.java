package Lab1;

import java.util.Scanner;

public class Power2 {
	public boolean checkNumber(int n)
	{
		boolean result=false;
		while(n>1)
		{
			if(n%2!=0)
			{
				result=false;
				break;
			}
			else
			{
				result=true;
				n=n/2;
			}
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    System.out.println("enter a number  ");
		int n=sc.nextInt();
		Power2 power=new Power2();
		System.out.println(power.checkNumber(n));	
	}

}
