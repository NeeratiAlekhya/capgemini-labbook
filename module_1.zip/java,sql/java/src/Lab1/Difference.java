package Lab1;

import java.util.Scanner;

public class Difference {
	public int calculateDifference(int n) {
		int b=0,i,sum=0;
		for(i=1;i<=n;i++)
		{
			sum+=(i*i);
			b+=i;
		}
		int bsum=b*b;
			sum-=bsum;
		 return sum;
	}
	public static void main(String[] args) {
		    Scanner sc = new Scanner(System.in);
		    System.out.println("enter a number  ");
			int n=sc.nextInt();
			Difference d=new Difference();
			System.out.println(d.calculateDifference(n));
			}
		}
