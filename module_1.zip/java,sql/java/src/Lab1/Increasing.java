package Lab1;

import java.util.Scanner;

public class Increasing {
	public boolean checkNumber(int n)
	{
		boolean result=false;
		while(n>=1)
		{
			int rem1=n%10;
			n/=10;
			int rem2=n%10;
			if(rem2<=rem1)
				result=true;
			else { 
				result=false;
				break;
				}
			rem1=rem2;
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
	    System.out.println("enter a number  ");
		int n= sc.nextInt();
		Increasing in= new Increasing();
		System.out.println(in.checkNumber(n));
	}
	}
