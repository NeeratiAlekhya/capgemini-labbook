package Lab2;

 abstract class MediaItem  extends Item {
	int runtime;
}
