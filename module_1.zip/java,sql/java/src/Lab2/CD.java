package Lab2;

public class CD extends MediaItem{
	private  String artist;
	 private String genre;
	 void print() {
		 System.out.println("CD bill is printed");
	 }
		 void addItem() {
			 System.out.println("CD added to library");
		 }	
		
		  void checkIn() {
			 System.out.println("CD checkin");
		 } 
		
		  void checkOut(){
			  System.out.println("checkout for a CD");
			 }  
}
