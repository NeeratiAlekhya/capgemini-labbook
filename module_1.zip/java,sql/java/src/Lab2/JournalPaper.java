package Lab2;

public class JournalPaper extends WrittenItem {
	private int yearOfPublish;
	 void print() {
		 System.out.println("library paper bill is printed");
	 }
		 void addItem() {
			 System.out.println("paper added in library");
		 }	
		
		  void checkIn() {
			 System.out.println("student checkin forpaper");
		 } 
		
		  void checkOut(){
			  System.out.println("check out for a paper");
			 }  
		
}
