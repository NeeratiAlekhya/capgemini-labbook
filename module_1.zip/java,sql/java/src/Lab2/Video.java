package Lab2;

public class Video extends MediaItem {
	 private String director;
	 private String genre;
	 private int yearReleased;
	 void print() {
		 System.out.println("video bill is printed");
	 }
		 void addItem() {
			 System.out.println("video added in library");
		 }	
		
		  void checkIn() {
			 System.out.println("video checkin");
		 } 
		
		  void checkOut(){
			  System.out.println("check out for a video");
			 }  
	
}
