package Lab2;

abstract class WrittenItem extends Item{
    String author;
}
