package Lab2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Book b=new Book();
		WrittenItem w=new Book();
		w.addItem();
		w.checkIn();
		w.checkOut();
	//	JournalPaper j=new JournalPaper();
		w=new JournalPaper();
		w.addItem();
		w.checkIn();
		w.checkOut();
	
   MediaItem m=new CD();
   m.addItem();
	m.checkIn();
	m.checkOut();
m= new Video();
m.addItem();
m.checkIn();
m.checkOut();
}
}
