package Lab8;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class ThreadTimer extends TimerTask implements Runnable{
	public void run()
	{
		System.out.println("Timer Update....."+ new Date());
	}
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		TimerTask timertask=new ThreadTimer();
		Timer timer=new Timer();
		timer.scheduleAtFixedRate(timertask,0,10*1000);
		System.out.println("Timer Update is started");
		Thread.sleep(100000);
		timer.cancel();
		System.out.println("Timer Update is stopped ");
		
		
	}
	}
