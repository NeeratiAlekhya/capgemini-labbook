package Lab8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileProgramJava {

	public static void main(String[] args) throws IOException, InterruptedException  {
		// TODO Auto-generated method stub
		FileInputStream f1=null;
		f1=new FileInputStream("c://files//sample.txt");
		FileOutputStream f2=null;
		f2=new FileOutputStream("c://files2//sample.txt");
		CopyDataThread c=new CopyDataThread(f1,f2);
	}

}
