package Lab9;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class DisplayingThreadTimer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Runnable task=()->{
            try {
            	while(true) {
                System.out.println("[ "+new Date()+" ]");
                TimeUnit.MILLISECONDS.sleep(10000);}
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        ExecutorService es= Executors.newFixedThreadPool(10);
        es.execute(task);
      
	}

}
