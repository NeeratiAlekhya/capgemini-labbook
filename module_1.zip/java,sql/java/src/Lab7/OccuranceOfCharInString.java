package Lab7;
import java.io.*;
import java.util.*;
public class OccuranceOfCharInString {
	public static Map<Character, Integer> countCharacter(char[] s)
	{
	Map<Character,Integer> CountMap=new HashMap<Character,Integer>();
	for(char x:s)
	{
	if(CountMap.containsKey(x))
	{
	CountMap.put(x,CountMap.get(x)+1);
	}
	else
	{
	CountMap.put(x,1);
	}
	}
	for(Map.Entry entry:CountMap.entrySet()){
	}
	return CountMap;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a string   ");
		String str=s.next();
		char[] strArray=str.toCharArray();
		OccuranceOfCharInString d=new OccuranceOfCharInString();
		Map<Character,Integer> Count=d.countCharacter(strArray);
		System.out.println(Count);
		}
	}
