package Lab7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class StudentMedal {
	public static HashMap<Integer,String> getStudents(HashMap<Integer,Integer> h)
	{
		HashMap<Integer,String> h1=new HashMap<Integer,String>();
		Set s=h.entrySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			Map.Entry entry=(Map.Entry)it.next(); 
			Integer id=(Integer) entry.getKey();
			Integer marks = (Integer) entry.getValue();
			//for (Integer id : h.keySet()) 
				//System.out.println(id);
				if(marks>=90)
				{
					h1.put(id,"Gold");
				}
				else if(marks>=80 && marks<90 ){
					h1.put(id, "Silver");
				}
				else if(marks>70 && marks<80){
					h1.put(id,"Bronze");}
		}
		return h1;
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number of students ");
		int n=sc.nextInt();
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		for(int i=0;i<n;i++)
		{
			System.out.println("enter id and marks of student "+i);
			Integer id=sc.nextInt();
			Integer marks=sc.nextInt();
			h.put(id, marks);
		}
		System.out.println(getStudents(h));
    
	}

}
