package Lab7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class VoterID {
	public static  ArrayList<Integer> votersList(Map<Integer,Integer> h)
	{
		HashMap<Integer,Integer> h1=new HashMap<Integer,Integer>();
		Set s=h.entrySet();
		Iterator it=s.iterator();
		while(it.hasNext())
		{
			Map.Entry entry=(Map.Entry)it.next(); 
			Integer value = (Integer) entry.getValue();
			
			if(value<=18)
			{
				it.remove();
			}
		}
		//System.out.println(h);
		ArrayList<Integer> al=new ArrayList<Integer>(h.keySet());
		return al;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value ");
		int n=sc.nextInt();
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		for(int i=0;i<n;i++)
		{
			System.out.println("enter id and age of person "+i);
			Integer id=sc.nextInt();
			Integer age=sc.nextInt();
			h.put(id, age);
		}
		System.out.println(votersList(h));
	}
	}

