package Lab7;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class RevSortArray {
	int[] getSorted(int[] a)
	{
	int[] b=new int[a.length];
	for(int i=0;i<a.length;i++)
	{
	String a1=Integer.toString(a[i]);
	StringBuffer ab=new StringBuffer(a1);
	b[i]=Integer.parseInt(ab.reverse().toString());
	}
	List<Integer> list=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
	list.add(b[i]);
	}
	Collections.sort(list);
	int[] arr=new int[a.length];
	for(int i=0;i<a.length;i++)
	{
	arr[i]=list.get(i);
	}
	return arr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RevSortArray d=new RevSortArray();
		Scanner sc=new Scanner(System.in);
	    System.out.println("enter array size   ");
	    int n = sc.nextInt();
		int [] a=new int[n];
	    System.out.println("enter array elements   ");
		for(int i=0;i<a.length;i++){
		a[i]=sc.nextInt();
		}
		int[] arr=d.getSorted(a);
		System.out.println(Arrays.toString(arr));
	}

}
