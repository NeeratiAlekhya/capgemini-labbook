package Lab7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SquareMap {
	//Accepts a list of numbers and return their squares 
		public static Map<Integer,Integer> getSquares(int[] a)
		{
			HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
			int s[]=new int[a.length];
			for(int i=0;i<a.length;i++)
			{
				s[i]=a[i]*a[i];
			}
			for(int i=0;i<a.length;i++){
				h.put(a[i],s[i]);			}
			Set kv=h.entrySet();
			Iterator it=kv.iterator();
			while(it.hasNext())
			{
				Map.Entry entry=(Map.Entry)it.next();
				System.out.println(entry.getKey()+":"+entry.getValue());
			}
			return h;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> a=new ArrayList<Integer>();
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array size ");
		n=sc.nextInt();
		System.out.println("enter the elements to find square ");
		for(int i=0;i<n;i++)
		{
			a.add(sc.nextInt());
		}
			//System.out.println(a);
		int[] arr = new int[a.size()];
		for (int i =0; i < a.size(); i++) 
            arr[i] = a.get(i);
		getSquares(arr);
	}

}
