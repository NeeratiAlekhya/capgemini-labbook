package Lab7;

import java.util.Scanner;
import java.util.TreeSet;

public class RemoveArrayDuplicates {
	//Remove duplicates  
		public static int[] modifyArray(int[] a)
		{
			TreeSet<Integer> s=new TreeSet<Integer>();
			for(Integer i:a)
				s.add(i);
		    //System.out.println(s);
		    TreeSet<Integer> res = (TreeSet<Integer>)s.descendingSet();
		    int[] a1=res.stream().mapToInt(Integer::intValue).toArray();
			return a1;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array size ");
		n=sc.nextInt();
		int[] a=new int[n];
		System.out.println("enter array elements ");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		int[] b=modifyArray(a);
       // System.out.println(modifyArray(a));
        for(int i=0;i<b.length;i++)
        	System.out.println(b[i]);
	}
	}
