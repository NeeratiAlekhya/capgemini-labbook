package Lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HashValues {
	public static ArrayList<Integer> getValues(Map<Integer,Integer> h)
	{
		ArrayList<Integer> a = new ArrayList<Integer>(h.values());
		Collections.sort(a);
		return a;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,Integer> h=new HashMap<Integer,Integer>();
		h.put(1,501);
		h.put(2,500);
		h.put(3,505);
		System.out.println(getValues(h));
	}
	}
