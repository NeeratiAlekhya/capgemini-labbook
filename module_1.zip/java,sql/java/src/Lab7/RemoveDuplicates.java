package Lab7;
import java.util.*;
public class RemoveDuplicates {
	int[] modifyArray(int[] a)
	{
	List<Integer> l=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
	l.add((Integer)a[i]);
	}
	Set<Integer> s=new HashSet<Integer>(l);
	List<Integer> list=new ArrayList<Integer>(s);
	Collections.sort(list);
	int[] b=new int[list.size()];
	int j=0;
	for(int i=list.size()-1;i>=0;i--)
	{
	b[j]=(Integer)list.get(i);
	j++;
	}
	return b;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoveDuplicates d=new RemoveDuplicates();
		int[] a=new int[5];
		int[] arr=new int[a.length];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
		a[i]=sc.nextInt();
		}
		arr=d.modifyArray(a);
		System.out.println(Arrays.toString(arr));
		}
	}

