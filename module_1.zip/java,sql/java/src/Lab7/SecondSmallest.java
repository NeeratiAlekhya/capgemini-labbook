package Lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class SecondSmallest {
	//Get the second smallest element in the array 
		public static int getSecondSmallest(int[] a)
		{
			ArrayList<Integer> al=new ArrayList<Integer>();
			for (int i = 0; i < a.length; i++) 
	            al.add(new Integer(a[i])); 
			Collections.sort(al);
			int[] arr=new int[al.size()];
			Iterator it=al.iterator();
			for(int i=0;i<al.size();i++)
			{
				arr[i]=al.get(i).intValue();
			}
			//for(int q:arr)
			//	System.out.println(q);
			return arr[1];
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				int n;
				Scanner sc=new Scanner(System.in);
				System.out.println("enter the array size ");
				n=sc.nextInt();
				int[] x=new int[n];
				System.out.println("enter array elements ");
				for(int i=0;i<n;i++)
				{
					x[i]=sc.nextInt();
				}
				System.out.println(getSecondSmallest(x));;
			}
	}
